#Convert image to schematic
java -jar MapConverter.jar output.png
#Copy this schematic from /out/schematic to your minecraft schematic folder
cp /home/lsannier/Desktop/jnbt/out/schematic/section.0.0.schematic /home/lsannier/.minecraft/config/worldedit/schematics/s.schematic
#xcopy for windows
